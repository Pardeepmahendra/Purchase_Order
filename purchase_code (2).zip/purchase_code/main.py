import sys
import os
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt,QDate, QDateTime
from PyQt5.QtGui import QFont,QIcon
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import QTimer, QDateTime
from style import *
from PyQt5.QtWidgets import QGraphicsDropShadowEffect


from pdf_generator import (
    generate_po_pdf,
    generate_word
)

def resource_path(relative_path):

    try:

        base_path = sys._MEIPASS

    except Exception:

        base_path = os.path.abspath(".")

    return os.path.join(
        base_path,
        relative_path
    )

class PurchaseOrder(QMainWindow):

    def __init__(self):

        super().__init__()

        self.setWindowTitle(
            "Silicon Engineers - Purchase Order Generator"
        )


        self.setGeometry(100, 40, 1300, 850)

        # ================= CENTRAL =================

        self.central_widget = QWidget()

        self.setCentralWidget(
            self.central_widget
        )

        self.main_layout = QVBoxLayout()

        self.central_widget.setLayout(
            self.main_layout
        )

        # ================= HEADER BAR =================

        self.header_layout = QHBoxLayout()

        # ================= LOGO =================

        self.logo = QLabel()

        pixmap = QPixmap(
            resource_path("logo_can.png")
        )

        self.logo.setPixmap(

            pixmap.scaled(
                50,
                50,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
        )

        # ================= WINDOW ICON =================

        self.setWindowIcon(
            QIcon(
                resource_path("logo.png")
            )
        )

        # ================= TITLE =================

        self.title = QLabel(
            "PURCHASE ORDER GENERATOR"
        )

        self.title.setAlignment(
            Qt.AlignCenter
        )

        self.title.setFont(
            QFont("Segoe UI", 16, QFont.Bold)
        )

        self.title.setStyleSheet(
            """
            QLabel{

                color:white;

                background-color:qlineargradient(
                    spread:pad,
                    x1:0,
                    y1:0,
                    x2:1,
                    y2:0,

                    stop:0 #0F2027,
                    stop:0.5 #203A43,
                    stop:1 #2C5364
                );

                padding:8px;

                border-radius:8px;

                border:1px solid #3A6073;

                letter-spacing:1px;
            }
            """
        )

        # ================= TIME =================

        self.time_label = QLabel()

        self.time_label.setAlignment(
            Qt.AlignCenter
        )

        self.time_label.setFont(
            QFont("Segoe UI", 11, QFont.Bold)
        )

        self.time_label.setStyleSheet(
            """
            QLabel{

                background-color:#16324F;

                color:#FFFFFF;

                padding:5px 10px;

                border-radius:6px;

                border:1px solid #2E5C88;

                min-width:170px;
            }
            """
        )

        # ================= TIMER =================

        self.timer = QTimer()

        self.timer.timeout.connect(
            self.update_time
        )

        self.timer.start(1000)

        self.update_time()

        # ================= ADD WIDGETS =================

        self.header_layout.addWidget(
            self.logo
        )

        self.header_layout.addStretch()

        self.header_layout.addWidget(
            self.title
        )

        self.header_layout.addStretch()

        self.header_layout.addWidget(
            self.time_label
        )

        # ================= HEADER FRAME =================

        self.header_frame = QFrame()

        self.header_frame.setLayout(
            self.header_layout
        )

        self.header_frame.setStyleSheet(
            """
            QFrame{

                background-color:#17202A;

                border-radius:10px;

                border:1px solid #2E4053;
            }
            """
        )
        self.main_layout.addWidget(
            self.header_frame
        )
            
        # ================= SCROLL =================

        self.scroll = QScrollArea()

        self.scroll.setWidgetResizable(True)

        self.scroll_widget = QWidget()

        self.scroll_layout = QVBoxLayout()

        self.scroll_widget.setLayout(
            self.scroll_layout
        )

        self.scroll.setWidget(
            self.scroll_widget
        )

        self.main_layout.addWidget(
            self.scroll
        )

        # ================= FORM =================

        self.form_layout = QFormLayout()

        self.po_no = QLineEdit()

        self.po_no.setText("SILIOCON/     /PO/26-27")

        self.date = QLineEdit()

        self.date.setText(
            QDate.currentDate().toString(
                "dd-MM-yyyy"
            )
        )

        self.to_address = QTextEdit()

        self.subject = QLineEdit()

        self.subject.setText("Purchase Order")

        self.ref_no = QLineEdit()

        self.ref_no.setText("Your Quote No: ")

        # self.model_no = QLineEdit()

        # self.part_no = QLineEdit()

        # ================= LETTER CONTENT =================

        self.letter_content = QTextEdit()

        self.letter_content.setMinimumHeight(150)

        self.letter_content.setStyleSheet(
            """
            QTextEdit{

                border:2px solid #D6DBDF;

                border-radius:8px;

                padding:6px;

                background:white;

                font-size:12px;

                font-family:Segoe UI;
            }

            QTextEdit:focus{

                border:2px solid #3498DB;
            }
            """
        )

        default_letter = f"""

        Dear Sir,

        Greetings from Silicon Engineers.

        With reference to the above subject and your above referred offer, we are pleased to place the order for the 

        following

        """
        self.letter_content.setPlainText(
            default_letter
        )

        self.form_layout.addRow(
            "PO Number :",
            self.po_no
        )

        self.form_layout.addRow(
            "Date :",
            self.date
        )

        self.form_layout.addRow(
            "To Address :",
            self.to_address
        )

        self.form_layout.addRow(
            "Subject :",
            self.subject
        )

        self.form_layout.addRow(
            "Reference No :",
            self.ref_no
        )

        # self.form_layout.addRow(
        #     "Model No :",
        #     self.model_no
        # )

        # self.form_layout.addRow(
        #     "P/No :",
        #     self.part_no
        # )

        self.form_layout.addRow(
            "Letter Content :",
            self.letter_content
        )

        self.scroll_layout.addLayout(
            self.form_layout
        )

        # ================= TABLE =================

        self.table = QTableWidget()

        self.table.setColumnCount(5)

        self.table.setHorizontalHeaderLabels([
            "S.No",
            "Model / Description",
            "Qty",
            "Unit Price",
            "Total Amount"
        ])

        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )

        self.table.setMinimumHeight(150)

        self.scroll_layout.addWidget(
            self.table
        )

        # ================= BUTTONS =================

        self.button_layout = QHBoxLayout()

        self.add_btn = QPushButton(
            "+ Add Row"
        )

        self.remove_btn = QPushButton(
            "- Remove Row"
        )

        self.generate_btn = QPushButton(
            "Generate Purchase Order"
        )

        self.add_btn.setStyleSheet(
            button_style
        )

        self.remove_btn.setStyleSheet(
            button_style
        )

        self.generate_btn.setStyleSheet(
            generate_style
        )

        self.button_layout.addWidget(
            self.add_btn
        )

        self.button_layout.addWidget(
            self.remove_btn
        )

        self.button_layout.addWidget(
            self.generate_btn
        )

        self.scroll_layout.addLayout(
            self.button_layout
        )

        # ================= TOTAL SECTION =================

        self.total_layout = QFormLayout()

        self.total = QLineEdit()

        self.gst = QLineEdit()

        self.grand_total = QLineEdit()

        self.total.setReadOnly(True)

        self.gst.setReadOnly(True)

        self.grand_total.setReadOnly(True)

        self.total_layout.addRow(
            "Total :",
            self.total
        )

        self.total_layout.addRow(
            "GST @18% :",
            self.gst
        )

        self.total_layout.addRow(
            "Grand Total :",
            self.grand_total
        )

        self.scroll_layout.addLayout(
            self.total_layout
        )

        # ================= TERMS =================

        self.delivery = QLineEdit()

        self.delivery.setText("At the Earliest")

        self.payment = QLineEdit()

        self.payment.setText("Online")

        self.warranty = QLineEdit()

        self.warranty.setText("1 Year")

        self.note = QTextEdit()

        self.note.setText("Please return the Purchase Order (PO) duly signed and stamped as a token of acceptance.")

        # self.shipping = QTextEdit()

        self.terms_layout = QFormLayout()

        self.terms_layout.addRow(
            "Delivery :",
            self.delivery
        )

        self.terms_layout.addRow(
            "Payment :",
            self.payment
        )

        self.terms_layout.addRow(
            "Warranty :",
            self.warranty
        )

        self.terms_layout.addRow(
            "Note :",
            self.note
        )

        # self.terms_layout.addRow(
        #     "Shipping Address :",
        #     self.shipping
        # )

        self.scroll_layout.addLayout(
            self.terms_layout
        )

        # ================= CONNECTIONS =================

        self.add_btn.clicked.connect(
            self.add_row
        )

        self.remove_btn.clicked.connect(
            self.remove_row
        )

        self.generate_btn.clicked.connect(
            self.generate_pdf
        )

        # self.model_no.textChanged.connect(
        #     self.update_letter
        # )

        # self.part_no.textChanged.connect(
        #     self.update_letter
        # )

        self.table.cellChanged.connect(
            self.calculate_total
        )

        # ================= START =================

        self.add_row()

    # ================= ADD ROW =================

    def add_row(self):

        row = self.table.rowCount()

        self.table.insertRow(row)

        sno = QTableWidgetItem(
            str(row + 1)
        )

        self.table.setItem(
            row,
            0,
            sno
        )

    # ================= REMOVE ROW =================

    def remove_row(self):

        row = self.table.currentRow()

        if row >= 0:

            self.table.removeRow(row)

        self.calculate_total()

    # ================= CALCULATE =================

    def calculate_total(self):

        self.table.blockSignals(True)

        total_amount = 0

        for row in range(
            self.table.rowCount()
        ):

            try:

                qty_item = self.table.item(
                    row,
                    2
                )

                price_item = self.table.item(
                    row,
                    3
                )

                qty = float(
                    qty_item.text()
                ) if qty_item else 0

                price = float(
                    price_item.text()
                ) if price_item else 0

                total = qty * price

                total_item = QTableWidgetItem(
                    str(round(total, 2))
                )

                total_item.setFlags(
                    Qt.ItemIsEnabled
                )

                self.table.setItem(
                    row,
                    4,
                    total_item
                )

                total_amount += total

            except:
                pass

        gst_amount = total_amount * 0.18

        grand_total = (
            total_amount + gst_amount
        )

        self.total.setText(
            str(round(total_amount, 2))
        )

        self.gst.setText(
            str(round(gst_amount, 2))
        )

        self.grand_total.setText(
            str(round(grand_total, 2))
        )

        self.table.blockSignals(False)

    def update_time(self):

        current_time = QDateTime.currentDateTime()

        formatted = current_time.toString(
            "ddd | dd MMM yyyy | hh:mm:ss AP"
        )

        self.time_label.setText(formatted)
        

    # ================= UPDATE LETTER =================

    def update_letter(self):

        letter = f"""Dear Sir,

    Greetings from Silicon Engineers.

    With reference to the above subject and your above referred offer, we are pleased to place the order for the 
    
    following

    """

        self.letter_content.setPlainText(
            letter
        )

    # ================= GENERATE =================

    def generate_pdf(self):

        try:

            file_type, ok = QInputDialog.getItem(

                self,

                "Save Type",

                "Select File Type:",

                ["PDF", "WORD"],

                0,

                False
            )

            if not ok:
                return

            # ================= SAVE PATH =================

            if file_type == "PDF":

                file_path, _ = QFileDialog.getSaveFileName(

                    self,

                    "Save PDF",

                    "",

                    "PDF Files (*.pdf)"
                )

            else:

                file_path, _ = QFileDialog.getSaveFileName(

                    self,

                    "Save Word",

                    "",

                    "Word Files (*.docx)"
                )

            if not file_path:
                return

            # ================= DATA =================

            data = {

                "po_no": self.po_no.text(),

                "date": self.date.text(),

                "to_address":
                self.to_address.toPlainText(),

                "subject":
                self.subject.text(),

                "ref_no":
                self.ref_no.text(),

                # "model_no":
                # self.model_no.text(),

                # "part_no":
                # self.part_no.text(),

                "delivery":
                self.delivery.text(),

                "payment":
                self.payment.text(),

                "warranty":
                self.warranty.text(),

                "note":
                self.note.toPlainText(),

                # "shipping":
                # self.shipping.toPlainText(),

                "letter":
                self.letter_content.toPlainText()

            }

            # ================= ITEMS =================

            items = []

            for row in range(
                self.table.rowCount()
            ):

                try:

                    description = self.table.item(
                        row,
                        1
                    ).text()

                    qty = float(
                        self.table.item(
                            row,
                            2
                        ).text()
                    )

                    price = float(
                        self.table.item(
                            row,
                            3
                        ).text()
                    )

                    items.append({

                        "description":
                        description,

                        "qty":
                        qty,

                        "price":
                        price
                    })

                except:
                    pass

            # ================= GENERATE =================

            if file_type == "PDF":

                generate_po_pdf(
                    data,
                    items,
                    file_path
                )

            else:

                generate_word(
                    data,
                    items,
                    file_path
                )

            QMessageBox.information(

                self,

                "Success",

                f"{file_type} Generated Successfully"
            )

        except Exception as e:

            QMessageBox.critical(

                self,

                "ERROR",

                str(e)
            )

            print(e)

# ================= APP =================

app = QApplication(sys.argv)

window = PurchaseOrder()

window.show()

sys.exit(app.exec_())
