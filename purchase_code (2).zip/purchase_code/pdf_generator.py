import os
import sys
from reportlab.platypus import *
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus.flowables import HRFlowable
from reportlab.platypus.tables import TableStyle
from reportlab.platypus import Image

from docx import Document
from docx.shared import Inches


def resource_path(relative_path):

    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

# ================= PDF GENERATOR =================

def generate_po_pdf(data, items, file_name):

    doc = SimpleDocTemplate(

        file_name,

        pagesize=A4,

        rightMargin=25,

        leftMargin=25,

        topMargin=18,

        bottomMargin=10
    )

    styles = getSampleStyleSheet()

    elements = []

    # ================= HEADER =================

    logo = Image(
        resource_path("silicon_logo.JPG"),
        width=110,
        height=65
    )


    header = Table([
        [
            "",
            logo
        ]
    ], colWidths=[390, 120])

    header.setStyle(TableStyle([

        ('ALIGN', (1,0), (1,0), 'RIGHT'),

        ('TOPPADDING', (0,0), (-1,-1), -28),

        ('BOTTOMPADDING', (0,0), (-1,-1), -18),

    ]))

    elements.append(header)

    # ================= PURCHASE ORDER =================

    title = Paragraph(

        """
        <para align=center>

        <font size=13>

        <b><u>PURCHASE ORDER</u></b>

        </font>

        </para>
        """,

        styles['Title']
    )

    elements.append(title)

    elements.append(Spacer(1, 1))

    # ================= PO DETAILS =================

    po_details = Table([

        [

            Paragraph(

                f"""

                <font size=11>

                <b>PO No:</b> {data['po_no']}

                </font>

                """,

                styles['BodyText']
            ),

            Paragraph(

                f"""

                <para align=right>

                <font size=11>

                <b>Date:</b> {data['date']}

                </font>

                </para>

                """,

                styles['BodyText']
            )
        ]

    ], colWidths=[250, 250])

    po_details.setStyle(TableStyle([

        ('BOTTOMPADDING', (0,0), (-1,-1), 0),

        ('TOPPADDING', (0,0), (-1,-1), 0),

    ]))

    elements.append(po_details)

    elements.append(HRFlowable(width="100%"))

    elements.append(Spacer(1, 2))

    # ================= TO ADDRESS =================

    to_text = f"""

    <font size=10>

    <b>To,</b><br/>

    {data['to_address'].replace('\n', '<br/>')}

    </font>

    """

    elements.append(

        Paragraph(
            to_text,
            styles['BodyText']
        )
    )

    elements.append(Spacer(1, 4))

    # ================= SUBJECT =================

    subject = f"""

    <font size=10>

    <b>Subject :</b> {data['subject']}<br/>

    <b>Reference No :</b> {data['ref_no']}

    </font>
    """

    elements.append(

        Paragraph(
            subject,
            styles['BodyText']
        )
    )

    elements.append(Spacer(1, 5))

    # ================= LETTER =================

    letter = f"""

    <font size=10>

    {data['letter'].replace('\n', '<br/>')}

    </font>

    """

    elements.append(

        Paragraph(
            letter,
            styles['BodyText']
        )
    )

    elements.append(Spacer(1, 5))


    # ================= ITEM TABLE =================

    table_data = [[

        "S.No",

        "Model / Description",

        "Qty",

        "Unit Price",

        "Total"

    ]]

    total = 0

    for i, item in enumerate(items, start=1):

        amount = item['qty'] * item['price']

        total += amount

        table_data.append([

            str(i),

            item['description'],

            str(item['qty']),

            str(item['price']),

            str(round(amount, 2))
        ])

    gst = total * 0.18

    grand_total = total + gst

    table_data.append([

        "", "", "",

        "TOTAL",

        str(round(total, 2))
    ])

    table_data.append([

        "", "", "",

        "GST @18%",

        str(round(gst, 2))
    ])

    table_data.append([

        "", "", "",

        "GRAND TOTAL",

        str(round(grand_total, 2))
    ])

    item_table = Table(

        table_data,

        colWidths=[45, 230, 55, 75, 95]
    )

    item_table.setStyle(TableStyle([

        ('GRID', (0,0), (-1,-1), 1, colors.black),

        ('BACKGROUND', (0,0), (-1,0),
         colors.HexColor("#1F3A5F")),

        ('TEXTCOLOR', (0,0), (-1,0),
         colors.white),

        ('FONTNAME', (0,0), (-1,0),
         'Helvetica-Bold'),

        ('ALIGN', (0,0), (-1,-1),
         'CENTER'),

        ('FONTSIZE', (0,0), (-1,-1), 9),

        ('BOTTOMPADDING', (0,0), (-1,-1), 4),

        ('TOPPADDING', (0,0), (-1,-1), 4),

    ]))

    elements.append(item_table)

    elements.append(Spacer(1, 4))

    # ================= TERMS =================

    terms = f"""

    <font size=9>

    <b><u>TERMS & CONDITIONS</u></b><br/><br/>

    &nbsp;&nbsp;&nbsp;&nbsp;1. <b>Taxes    :</b> GST @18% As Included Above<br/>

    &nbsp;&nbsp;&nbsp;&nbsp;2. <b>Delivery :</b> {data['delivery']}<br/>

    &nbsp;&nbsp;&nbsp;&nbsp;3. <b>Payment  :</b> {data['payment']}<br/>

    &nbsp;&nbsp;&nbsp;&nbsp;4. <b>GST      :</b> 36BRFPG5330Q1ZH<br/>

    &nbsp;&nbsp;&nbsp;&nbsp;5. <b>PAN      :</b> BRFPG5330Q<br/>

    &nbsp;&nbsp;&nbsp;&nbsp;6. <b>Warranty :</b> {data['warranty']}<br/><br/>

    &nbsp;&nbsp;&nbsp;&nbsp;<b>NOTE :</b> {data['note']}

    </font>
    """

    elements.append(

        Paragraph(
            terms,
            styles['BodyText']
        )
    )

    elements.append(Spacer(1, 3))

    # ================= ADDRESS =================

    billing = """

    <font size=8>

    <b><u>BILLING ADDRESS:</u></b><br/>

    SILICON ENGINEERS<br/>

    FLAT No:401,H.No:11-02472/8<br/>

    NAMALAGUNDU, PADMARAO NAGAR<br/>

    SECUNDERABAD, TELANGANA<br/>

    PIN - 500061

    </font>
    """

    shipping = """

    <font size=8>

    <b><u>SHIPPING ADDRESS:</u></b><br/>

    SILICON ENGINEERS<br/>

    FLAT NO:45, MANSOORABAD<br/>

    DP NAGAR ROAD NO 1<br/>

    HYDERABAD, TELANGANA<br/>

    PIN - 500068

    </font>
    """

    address_table = Table([

        [

            Paragraph(
                billing,
                styles['BodyText']
            ),

            Paragraph(
                shipping,
                styles['BodyText']
            )
        ]

    ], colWidths=[260, 260])

    address_table.setStyle(TableStyle([

        ('BOX', (0,0), (-1,-1), 1.2, colors.black),

        ('INNERGRID', (0,0), (-1,-1), 1, colors.black),

        ('VALIGN', (0,0), (-1,-1), 'TOP'),

        ('BACKGROUND', (0,0), (-1,-1),
         colors.HexColor("#F8F9F9")),

        ('BOTTOMPADDING', (0,0), (-1,-1), 5),

        ('TOPPADDING', (0,0), (-1,-1), 5),

        ('LEFTPADDING', (0,0), (-1,-1), 8),

    ]))

    elements.append(address_table)

    elements.append(Spacer(1, 5))

    # ================= SIGNATURE =================

    sign = """

    <font size=9>

    With Best Regards,<br/><br/>

    <b>FOR SILICON ENGINEERS</b><br/><br/><br/><br/>

    <b>Authorized Signatory</b>

    </font>
    """

    signature_para = Paragraph(
        sign,
        styles['BodyText']
    )

    elements.append(signature_para)

    # ================= PUSH FOOTER TO BOTTOM =================

    elements.append(Spacer(1, 35))



    # ================= FOOTER =================

    footer = Paragraph(

        """
        <para align=center>

        <font size=8 color=white>

        SILICON ENGINEERS |
        siliconengineers2015@gmail.com |
        sales@siliconengineers.in |
        PH: 8978777313

        </font>

        </para>
        """,

        styles['BodyText']
    )

    footer_table = Table([

        [footer]

    ], colWidths=[520])

    footer_table.setStyle(TableStyle([

        ('LINEABOVE', (0,0), (-1,-1),
        0.5, colors.black),

        ('BACKGROUND', (0,0), (-1,-1),
        colors.HexColor("#1F3A5F")),

        ('TEXTCOLOR', (0,0), (-1,-1),
        colors.white),

        ('BOTTOMPADDING', (0,0), (-1,-1), 1),

        ('TOPPADDING', (0,0), (-1,-1), 1),

        ('LEFTPADDING', (0,0), (-1,-1), 5),

        ('RIGHTPADDING', (0,0), (-1,-1), 5),

    ]))

    elements.append(footer_table)

    # ================= BUILD PDF =================

    doc.build(elements)


# ================= WORD GENERATOR =================

def generate_word(data, items, file_name):

    doc = Document()

    doc.add_picture(
        resource_path("silicon_logo.JPG"),
        width=Inches(1.5)
    )


    doc.add_heading(
        'PURCHASE ORDER',
        level=1
    )

    doc.add_paragraph(
        f"PO No: {data['po_no']}"
    )

    doc.add_paragraph(
        f"Date: {data['date']}"
    )

    doc.add_paragraph(
        f"To:\n{data['to_address']}"
    )

    table = doc.add_table(
        rows=1,
        cols=5
    )

    hdr = table.rows[0].cells

    hdr[0].text = 'S.No'
    hdr[1].text = 'Description'
    hdr[2].text = 'Qty'
    hdr[3].text = 'Price'
    hdr[4].text = 'Total'

    for i, item in enumerate(items, start=1):

        row = table.add_row().cells

        row[0].text = str(i)
        row[1].text = item['description']
        row[2].text = str(item['qty'])
        row[3].text = str(item['price'])
        row[4].text = str(
            item['qty'] * item['price']
        )

    doc.save(file_name)