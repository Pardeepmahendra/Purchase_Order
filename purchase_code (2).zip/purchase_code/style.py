title_style = """

QLabel{

    background-color:#1F3A5F;

    color:white;

    padding:18px;

    border-radius:10px;

    font-size:24px;

    font-weight:bold;
}
"""

button_style = """

QPushButton{

    background-color:#3498DB;

    color:white;

    font-size:15px;

    padding:12px;

    border:none;

    border-radius:6px;

    font-weight:bold;
}

QPushButton:hover{

    background-color:#2980B9;
}
"""

generate_style = """

QPushButton{

    background-color:#27AE60;

    color:white;

    font-size:16px;

    padding:14px;

    border:none;

    border-radius:6px;

    font-weight:bold;
}

QPushButton:hover{

    background-color:#1E8449;
}
"""

line_edit_style = """

QLineEdit{

    border:2px solid #D5D8DC;

    border-radius:6px;

    padding:8px;

    font-size:14px;

    background:white;
}

QLineEdit:focus{

    border:2px solid #3498DB;
}
"""

text_edit_style = """

QTextEdit{

    border:2px solid #D5D8DC;

    border-radius:6px;

    padding:8px;

    font-size:14px;

    background:white;
}

QTextEdit:focus{

    border:2px solid #3498DB;
}
"""

table_style = """

QTableWidget{

    border:1px solid #BDC3C7;

    gridline-color:#D5D8DC;

    font-size:14px;

    background:white;
}

QHeaderView::section{

    background-color:#1F3A5F;

    color:white;

    padding:10px;

    border:none;

    font-weight:bold;
}
"""
